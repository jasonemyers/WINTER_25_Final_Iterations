import React from "react";
import "../styles/SideMenu.css";

const SideMenu = () => {

    return(
        <div className="side-menu-container">
            <div className="side-menu">
                <div className="routed-icons">
                    <div className="side-menu-title"><h2>Your profile</h2></div>

                    <div className="search-for-jobs">
                        <img src="../src/assets/search.svg" width="40px" />
                        <span>Search for jobs</span>
                    </div>

                    <div className="your-favorited-schools">
                        <img src="../src/assets/favorite.svg" width="40px"/> 
                        <span>Your favorited schools</span>
                    </div>

                    <div className="sub-resources">
                        <img src="../src/assets/resources.svg" width="40px"/>
                        <span>Sub resources</span>
                    </div>

                    <div className="update-your-districts">
                        <img src="../src/assets/update-district.svg" width="40px"/> 
                        <span>Update your districts</span>
                    </div>

                    <div className="faq">
                        <img src="../src/assets/faq.svg" width="40px"/>
                        <span>FAQ</span>
                    </div>
                </div>
            </div>
        </div>


    );
}

export default SideMenu;