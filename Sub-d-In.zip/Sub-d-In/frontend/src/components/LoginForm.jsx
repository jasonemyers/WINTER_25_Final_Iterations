import React from 'react';
import "../styles/Login.css";






const Login = () => {
  
      // grab the button to listen for click event by using it's unique CSS id
      const loginSubmit = document.querySelector("#login-submit-button-event-handler");

      // add the event listener: the listener will look out a "click" event on the button, and then call the function "loginSubmitClick" below
      loginSubmit.addEventListener("click", loginSubmitClick);
      
      function loginSubmitClick(e) {
        e.preventDefault();
        console.log("Success!");
      }

    return (

        // container holding all login information
        <div className="login-page">
            <div className="login-container">
                <section className="login-header">
                    <h1>Welcome back!</h1>
                    <p>Log in to access your account!</p>
                </section>

                <form action="http://127.0.0.1:8000/admin-user-profiles/" method="POST">
                    <div>
                        <label htmlFor="username">Username:</label>
                        <input type="text" id="username" name="username" />
                    </div>
                    <div>
                        <label htmlFor="password">Password:</label>
                        <input type="password" id="password" name="password" />
                    </div>
                    <button id="login-submit-button-event-handler" onClick="loginSubmitClick()" type="submit">Login</button>
                </form>
                
                <section className="login-sign-up">
                    <p>Don't have an account? <a href="/signup">Sign up here!</a></p>
                </section>
            </div>
        </div>
    );
};

export default Login;
