// Reusable form for creating and updating profiles
// We will be able to update/upload user info such as name, topics, profile picture, etc

import React from "react";
import axios from "axios";
import '../styles/ProfileForm.css';
import { useState, useRef } from "react";
import { Link } from "react-router-dom";


const ProfileForm = () => {

    const render = () => {
        const { signup } = this.props.location
        return (
            signup
        );
      };


   

    // handle form submission
    const handleSubmit = async (event) => {

        event.preventDefault();


        // this is the hard-coded version, take this out when we redo stuff
        window.location.href = "/profile";


        const info = {
            username: render.username,
            email: render.email,
            password: render.password,
            first_name: firstname,
            last_name: lastname,
            subjects: subjects,
            location: location,
            bio: bio,

        }
    
        try {
            const response = await axios.put('http://localhost:8000/signup', info, {
                headers: {
                    'Content-Type': 'application/json',
                },
            });
    
            if (response.status === 201) {
              console.log(response.data); // Handle success
            }
    
        } catch (error) {
            console.error(error.response.data); // Handle error
        }
    };
   
 

    return (

        <form className="profile-form" onSubmit={handleSubmit}>
            {/* Input fields for user profile */}

            {/* Below we take text input for the users full name, full name will be a placeholder till the user types something, the value that we are changing is name */}
            {/* onChange set name with the value */}
            <div className="text-entries">
                <h2>About</h2>
                <p>Enter your full name, prefered teaching topics, and where you are located.</p>
                <br></br>
                <input type="text" placeholder="First name"/>
                <br></br>
                <input type="text" placeholder="Last name"/>
                <br></br>
                <input type="text" placeholder="Teaching Topics"/>
                <br></br>
                <input type="text" placeholder="Location"/>
                <br></br>
                <h2>Bio</h2>
                <p>Your bio is your resume, say why you should be hired and what makes you stand out.</p>
                {/* text area for user bio, used for multiline user input */}
                <textarea placeholder="Enter a bio!"></textarea>
                <br></br>
                <br></br>
            </div>
            {/* Submit users data */}
            <button type="submit">Save Profile</button>
        </form>
    );
};

export default ProfileForm;