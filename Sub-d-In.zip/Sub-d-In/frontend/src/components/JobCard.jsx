import React, { useState } from "react";
import axios from "axios";
import "../styles/JobCard.css";
import Popup from "../components/JobPopup.jsx";

// display single job postings

// job card directly recieves the values it needs rather than needing to reference the props
const JobCard = ({ id, school, teacher, grade, subject, accepted, description }) => {
    // state to track the job availability, will let us hide the job if accepted
    const [available, setAvailable] = useState(!accepted);
    const [buttonPopup, setButtonPopup] = useState(false);

    // accept job function
    const handleAccept = async () => {
        setAvailable(false); // update the ui immediately to show the job is accepted

        // Data object to send update job info to backend
        const updateJob = {
            id: id,
            school: school,
            teacher: teacher,
            grade: grade,
            subject: subject,
            accepted: true, // update backend status to accepted
            description: description
        };

        try {
            // sned updated job data to the backend
            // http://localhost:8000/path/jobs/${id} was this before
            const response = await axios.put(`http://localhost:8000/path/jobs/${id}`, updateJob, {
                headers: {
                    "Content-Type": "application/json",
                },
            });

            if (response.status === 200) {
                console.log("Job accepted:", response.data); // successful
            }
        } catch (error) {
            console.error("Error accepting job:", error.response?.data || error.message);
            setAvailable(true); // reset the state if api fails
        }
    };

    if (!available) {
        return null; // if job is accepted remove that job from the list! We wont display it
    }






    return (
        <div className="job-card-container">
            <button onClick={() => setButtonPopup(!buttonPopup)} className="job-card">
                <h3>Job Listing</h3>
                <div className="job-details">
                    <p><strong>School: </strong>{school}</p>
                    <p><strong>Teacher: </strong>{teacher}</p>
                    <p><strong>Grade: </strong>{grade}</p>
                    <p><strong>Subject: </strong>{subject}</p>


                    <button onClick={handleAccept}>
                        {available ? "Accept Job" : "Accepted!"}
                    </button>
                </div>
            </button>
            <div className="popup-area">
                <Popup trigger={buttonPopup}>
                    <p><strong>Description: </strong>{description}</p>
                </Popup>
            </div>
        </div>

    );
};

export default JobCard;