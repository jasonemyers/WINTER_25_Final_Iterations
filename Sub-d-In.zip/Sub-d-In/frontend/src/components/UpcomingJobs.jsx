import React from "react";
import "../styles/UpcomingJobs.css";

function UpcomingJobs(props) {

    return(
        <div className="upcoming-job-container">
        <div className="upcoming-job">
            <div className="job-info">
                <div className="job-school"><p className="profile-bold">School: {props.school}</p></div>
                <div className="job-date"><p className="profile-bold">Date: {props.date}</p></div>
                <div className="job-grade"><p className="profile-bold">Grade: {props.grade}</p></div>
                <div className="job-description"><p className="profile-bold">Decription: {props.description}</p></div>
                <div className="job-times"><p className="profile-bold">Times: {props.times}</p></div>
            </div>

        </div>
        </div>


    );
}

export default UpcomingJobs;