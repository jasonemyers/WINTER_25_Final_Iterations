import React from "react";
import { Link } from "react-router-dom";
import '../styles/Footer.css';



const Footer = () => {

    return (
        <footer className="job-footer-section">
            <div className="job-footer-content">
                <div className="job-footer-column">
                    <h3>Company</h3>
                        <Link to="/aboutus">About Us</Link>
                        <Link to="#">Contact</Link>
                        {/* REMOVE LATER */}
                        <Link to="/create-profile">Profile Creator</Link>
                </div>
                <div className="job-footer-column">
                    <h3>Support</h3>
                    <Link to="#">Help Center</Link>
                    <Link to="/Terms">Terms of Service</Link>
                    <Link to="/PrivacyPolicy">Privacy Policy</Link>
                </div>
                <div className="job-footer-column">
                    <h3>Connect</h3>
                    <a href="#" className="social-link">Twitter</a>
                    <a href="#" className="social-link">LinkedIn</a>
                </div>
            </div>
        </footer>
    );
}

export default Footer;