import React, { useState, useEffect } from "react";
import "../styles/UserAgreementPopup.css";

const UserAgreementPopup = () => {
    //  Use state to either show or hide the popup, everytime homepage is loaded will show until accepted
    // always initialize to true so it shows up when the page is loaded
    const [showPopup, setShowPopup] = useState(true);

    // Function to handle the accept button when user clicks it
    const handleAccept = () => {
        setShowPopup(false);
    };

    // renders popup if it is true!
    return (
        showPopup && ( // if showPopup is true, show the popup using the jsx below
            <div className="user-agreement-popup">
                <div className="user-agreement-popup-container">
                    <h1 className="user-agreement-popup-title">We've updated our terms.</h1>
                    <p className="user-agreement-popup-paragraph">
                        Sub'd-In has updated its {" "}
                        {/* Links to privacy policy and user agreement */}
                        <a href="/terms" className="user-agreement-popup-link">User Agreement</a>
                        {" "}and{" "}
                        <a href="/privacypolicy" className="user-agreement-popup-link">Privacy Policy</a>
                        . Please take a moment to review these changes.
                    </p>
                    <button className="user-agreement-popup-button" onClick={handleAccept}>
                        Accept
                    </button>
                </div>
            </div>
        )
    );
};

export default UserAgreementPopup;