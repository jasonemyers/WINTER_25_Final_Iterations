import React from "react";
import { Link } from "react-router-dom";
import "../styles/Navbar.css";

const Navbar = () => {
    return (
        // Navbar component following s and o of the solid principles
        // it only is used to traverse the website and does not have any other responsibilities
    
        <header className="navbar">
            {/* Website title, add actual logo later */}
            <h1 className="logo">
                <Link to="/" className="logo-link">
                <img src="../src/assets/logo.png" alt="Sub'd-In Logo" className="logo-image" />
                </Link>
            </h1>
            {/* links for home, about us, login, and sign up */}
            <nav className="nav-links">
                {/* These will navigate to the respective pages */}
                <Link to="/login" className="nav-item">Log in</Link> 
                <Link to="/signup" className="nav-item">Sign Up</Link> 
                <Link to="/profile" className="nav-item">
                    <img src="../src/assets/profile.png" alt="Profile" className="profile-icon" />
                </Link>
            </nav>
        </header>
    );
};

export default Navbar;