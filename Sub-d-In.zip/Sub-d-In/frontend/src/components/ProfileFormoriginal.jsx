// Reusable form for creating and updating profiles
// We will be able to update/upload user info such as name, topics, profile picture, etc

import React from "react";
import axios from "axios";
import '../styles/ProfileForm.css';
import { useState, useRef } from "react";
import { Link } from "react-router-dom";


const ProfileForm = () => {
    // handle file upload for user image
    // form submissions

    // state variables for input
    const [email, setEmail] = useState('');
    const [name, setName] = useState('');
    const [lastName, setLastName] = useState('')
    const [topics, setTopics] = useState('');
    const [location, setLocation] = useState('');
    const [bio, setBio] = useState('');
    const [profilePicture, setProfilePicture] = useState(null);
    const [avatar, setAvatar] = useState(null);
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const fileInputField = useRef(null);
    // add preview so user can see image? Come back to later

    const toBase64 = file => new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result.split(',')[1]);
        reader.onerror = reject;
    });

    const handleFileChange = (event) => {
        const file = event.target.files[0]; // get the file user selected
        if (file) {
            setProfilePicture(URL.createObjectURL(file)); // set the file to the state
        }
        setAvatar(toBase64(file));
        console.log(avatar);
        
            
        

    };
    
      

    const render = () => {
        const { signup } = this.props.location
        return (
            console.log("Username: ", signup.username)
        );
      };


   

    // handle form submission
    const handleSubmit = async (event) => {
        event.preventDefault(); // will not refresh the page when submitted
        // will print info to the console for now
        //console.log("Profile updated:", { profilePicture, name, topics, location, bio });

        console.log("TRYING TO RENDER", render());



        const data = {
          last_name: lastName,
          first_name: name,
          email: email,
          topics: topics,
          location: location,
          bio: bio,
          //avatar: avatar,
          username: username,
          password: password
      };

        
        

     
        
          
        
        
     

        console.log(data);

        try {
            const response = await axios.post('http://localhost:8000/signup/', data, {
                headers: {
                    "Content-Type": "application/json",
                },
                                
            });

            if (response.status === 201) {

                console.log(response.data); // Handle success
            }

        }catch (error) {
            console.error(error.response.data); // Handle error
        }
    };
   
 

    return (

        <form className="profile-form" onSubmit={handleSubmit}>
            {/* Input fields for user profile */}

            {/* input for user profile picture, will only accept image files */}
            <div>
                <h2>Choose an avatar</h2>
                <p>Your avatar represents you to potential employers, keep it professional. Inapropriate profile pictures will be removed.</p>
                <div className="image-preview">
                    <label htmlFor="profile-picture" className="file-upload" onClick={() => fileInputField.current.click() }>Upload Avatar</label>
                    <input type="file" accept="image/jpeg,image/png" onChange={handleFileChange} ref={fileInputField} />
                    <img src={profilePicture} />
                </div>
            </div>

            {/* Below we take text input for the users full name, full name will be a placeholder till the user types something, the value that we are changing is name */}
            {/* onChange set name with the value */}
            <div className="text-entries">
                <h2>About</h2>
                <p>Enter your full name, prefered teaching topics, and where you are located.</p>
                <input type="text" placeholder="Email" value={email} onChange={event => setEmail(event.target.value)} />
                <br></br>
                <input type="text" placeholder="First name" value={name} onChange={event => setName(event.target.value)} />
                <br></br>
                <input type="text" placeholder="Last name" value={lastName} onChange={event => setLastName(event.target.value)}/>
                <br></br>
                <input type="text" placeholder="Teaching Topics" value={topics} onChange={event => setTopics(event.target.value)} />
                <br></br>
                <input type="text" placeholder="Location" value={location} onChange={event => setLocation(event.target.value)} />
                <br></br>
                <input type="text" placeholder="Username" value={username} onChange={event => setUsername(event.target.value)} />
                <br></br>
                <input type="text" placeholder="Password" value={password} onChange={event => setPassword(event.target.value)}/>
                <h2>Bio</h2>
                <p>Your bio is your resume, say why you should be hired and what makes you stand out.</p>
                {/* text area for user bio, used for multiline user input */}
                <textarea placeholder="Enter a bio!" value={bio} onChange={event => setBio(event.target.value)}></textarea>
                <br></br>
                <br></br>
            </div>
            {/* Submit users data */}
            <button type="submit">Save Profile</button>
        </form>
    );
};

export default ProfileForm;