import React from 'react';
import "../styles/MockJobCard.css";

// MockJobCard styled like the real job card
const MockJobCard = ({ school, teacher, grade, subject, date }) => {
  return (
    <div className="my-job-card">
      <div className="main-my-job-card">
            <div className="title-my-job-card">{school}</div>
            <div className="flex-tags-my-job-card">
                <div className="flex-item-tags-my-job-card">full day</div>
                {/*}<div className="flex-item-tags-my-job-card">9th</div>
                <div className="flex-item-tags-my-job-card">10th</div>{*/}
                <div className="flex-item-tags-my-job-card">11th</div>
                <div className="flex-item-tags-my-job-card">12th</div>
            </div>
            <div className="pay-and-subject-my-job-card"><p className="pay-my-job-card">$110/day</p><p className="subject-my-job-card">{subject} teacher</p></div>
            <div className="flex-details-my-job-card">
                <div className="flex-icon-details-my-job-card"><img src="../src/assets/person.svg" width="10px"></img></div>
                <div className="flex-text-details-my-job-card">{teacher}</div>
                <div className="flex-icon-details-my-job-card"><img src="../src/assets/clock.svg" width="10px"></img></div>
                <div className="flex-text-details-my-job-card">7:00am-3:00pm</div>
                <div className="flex-icon-details-my-job-card"><img src="../src/assets/calendar.svg" width="10px"></img></div>
                <div className="flex-text-details-my-job-card">April 23</div>
            </div>
        <div className="accept-button-my-job-card-div">
          <button className="accept-button-my-job-card" disabled>
            Accept Job
          </button>
        </div>
      </div>
    </div>
  );
};

export default MockJobCard;