import React, { useState } from "react";
import axios from "axios";
import "../styles/JobCard.css";
//import Popup from "../components/JobPopup.jsx";

function MyJobCard(props) {

    const [available, setAvailable] = useState(true);

    const accept = (event) => {
        setAvailable(!available);
        handleAccept(event);
    };

    const jobid = props.id;
    const school = props.school;
    const teacher = props.teacher;
    const grade = props.grade;
    const subject = props.subject;
    const accepted = props.accepted;
  
  
    const handleAccept = async (event) => {
  
      const updateAccept = {
        id: props.id,
        school: props.school,
        teacher: props.teacher,
        grade: props.grade,
        subject: props.subject,
        accepted: true
      }
  
      try {
          const response = await axios.put('http://localhost:8000/jobs/'+jobid, updateAccept, {
              headers: {
                  'Content-Type': 'application/json',
              },
          });
  
          if (response.status === 201) {
            console.log(response.data); // Handle success
          }
  
      } catch (error) {
          console.error(error.response.data); // Handle error
      }
  };

  if (available === true && accepted === false) {
    return(
    <div className="my-job-card">
        <div className="main-my-job-card">
            <div className="title-my-job-card">{school}</div>
            <div className="flex-tags-my-job-card">
                <div className="flex-item-tags-my-job-card">full day</div>
                {/*}<div className="flex-item-tags-my-job-card">9th</div>
                <div className="flex-item-tags-my-job-card">10th</div>{*/}
                <div className="flex-item-tags-my-job-card">11th</div>
                <div className="flex-item-tags-my-job-card">12th</div>
            </div>
            <div className="pay-and-subject-my-job-card"><p className="pay-my-job-card">$110/day</p><p className="subject-my-job-card">{subject} teacher</p></div>
            <div className="flex-details-my-job-card">
                <div className="flex-icon-details-my-job-card"><img src="../src/assets/person.svg" width="10px"></img></div>
                <div className="flex-text-details-my-job-card">{teacher}</div>
                <div className="flex-icon-details-my-job-card"><img src="../src/assets/clock.svg" width="10px"></img></div>
                <div className="flex-text-details-my-job-card">7:00am-3:00pm</div>
                <div className="flex-icon-details-my-job-card"><img src="../src/assets/calendar.svg" width="10px"></img></div>
                <div className="flex-text-details-my-job-card">April 23</div>
            </div>
            <div className="accept-button-my-job-card-div"><button className="accept-button-my-job-card" onClick={accept}>{available ? 'Accept job' : 'Accepted!'}</button></div>
        </div>
    </div>
    )
} else {
    return(null);
  }
}

export default MyJobCard;