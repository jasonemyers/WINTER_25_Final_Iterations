import React from "react";
import "../styles/ProfileContent.css";

const ProfileContent = () => {

    return(
        <div className="profile-data-container">
        <div className="profile-data">
            <div className="info">
                <div className="subjects"><p className="profile-bold">Preferred subjects: Math, Science</p></div>
                <div className="location"><p className="profile-bold">Location: Detroit, MI</p></div>
                <div className="biography"><p className="profile-bold">About me: Teaching is my passion!</p></div>
            </div>

        </div>
        </div>


    );
}

export default ProfileContent;