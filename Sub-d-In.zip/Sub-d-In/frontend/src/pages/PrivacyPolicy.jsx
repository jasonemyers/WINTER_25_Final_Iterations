import React from "react";
import "../styles/PrivacyPolicy.css";

const PrivacyPolicy = () => {
    return (
        <div className="privacy-background">
            <div className="privacy-policy-container">
                <h1 className="privacy-policy-title">Privacy Policy</h1>
                <p className="privacy-policy-intro">
                    Your privacy is important to us. This Privacy Policy explains how we collect, use, and protect your information.
                </p>

                <section className="privacy-policy-section">
                    <h2 className="privacy-policy-subtitle">1. Information We Collect</h2>
                    <p className="privacy-policy-text">
                        We may collect personal information such as your name, email address, phone number, and any other details you provide to us.
                        Additionally, we may collect non-personal information such as your IP address, browser type, and usage data to improve our services.
                    </p>
                </section>

                <section className="privacy-policy-section">
                    <h2 className="privacy-policy-subtitle">2. How We Use Your Information</h2>
                    <p className="privacy-policy-text">
                        We use your information to:
                    </p>
                    <ul className="privacy-policy-list">
                        <li>Provide and improve our services.</li>
                        <li>Communicate with you regarding updates, promotions, or support.</li>
                        <li>Ensure a better user experience by analyzing usage data.</li>
                    </ul>
                </section>

                <section className="privacy-policy-section">
                    <h2 className="privacy-policy-subtitle">3. Sharing Your Information</h2>
                    <p className="privacy-policy-text">
                        We do not sell or rent your personal information to third parties. However, we may share your information with trusted partners
                        to provide services on our behalf, such as payment processing or email delivery, under strict confidentiality agreements.
                    </p>
                </section>

                <section className="privacy-policy-section">
                    <h2 className="privacy-policy-subtitle">4. Data Protection</h2>
                    <p className="privacy-policy-text">
                        We take reasonable measures to protect your information from unauthorized access, disclosure, or misuse. However, no method of
                        transmission over the internet or electronic storage is 100% secure, and we cannot guarantee absolute security.
                    </p>
                </section>

                <section className="privacy-policy-section">
                    <h2 className="privacy-policy-subtitle">5. Your Rights</h2>
                    <p className="privacy-policy-text">
                        You have the right to access, update, or delete your personal information. If you wish to exercise these rights, please contact us
                        at support@example.com.
                    </p>
                </section>

                <section className="privacy-policy-section">
                    <h2 className="privacy-policy-subtitle">6. Changes to This Privacy Policy</h2>
                    <p className="privacy-policy-text">
                        We may update this Privacy Policy from time to time. Any changes will be posted on this page with an updated effective date.
                        We encourage you to review this Privacy Policy periodically to stay informed about how we are protecting your information.
                    </p>
                </section>

                <section className="privacy-policy-section">
                    <h2 className="privacy-policy-subtitle">7. Contact Us</h2>
                    <p className="privacy-policy-text">
                        If you have any questions about this Privacy Policy, please contact us at support@example.com.
                    </p>
                </section>
            </div>
        </div>
    );
};

export default PrivacyPolicy;
