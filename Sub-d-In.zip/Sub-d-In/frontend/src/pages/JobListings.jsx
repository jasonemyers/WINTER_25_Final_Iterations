import React, { useState, useEffect } from "react";
import axios from "axios";
import MyJobCard from "../components/MyJobCard";
import SideMenu from "../components/SideMenu";
import "../styles/JobListings.css";


function Jobs() {
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
  
  
    useEffect(() => {
      const fetchData = async () => {
        try {
          const response = await axios.get('http://localhost:8000/jobs/');
          setData(response.data.results);
        } catch (err) {
          setError(err);
        } finally {
          setLoading(false);
        }
      };
  
      fetchData();
      
    }, []); // The empty dependency array ensures this effect runs only once after the initial render
  
    if (loading) {
      return <p>Loading...</p>;
    }
  
    if (error) {
      return <p>Error: {error.message}</p>;
    }
  

  // New job listings page with side menu and new joblistings boxes
  return (
    <div className="job-listing-page">
      <div className="job-listing-main-container">
          <div className="job-listing-side-menu">
            <SideMenu />
          </div>


        <div className="job-listings-flex-container">
            {data.map(item => (
                <div className="job-listings-flex-items">
                <MyJobCard key={item.id}
                id = {item.id}
                school = {item.school}
                teacher = {item.teacher}
                grade = {item.grade}
                subject = {item.subject}
                accepted = {item.accepted}/>
                </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Jobs;
