import React from 'react';
import "../styles/Terms.css";

const Terms = () => {
    return (
        <div className="terms-background">
            <div className="terms-container">
                <h1>Terms and Conditions</h1>
                <p>Welcome to our Terms and Conditions page. Please read carefully.</p>
                <section className="terms-section">
                    <h2>1. Introduction</h2>
                    <p>
                        These terms and conditions outline the rules and regulations for the use of our website and services.
                        By accessing this website, we assume you accept these terms and conditions in full. Do not continue to use our website
                        if you do not accept all of the terms and conditions stated on this page.
                    </p>
                </section>
                <section className="terms-section">
                    <h2>2. Intellectual Property Rights</h2>
                    <p>
                        Unless otherwise stated, we or our licensors own the intellectual property rights for all material on this website.
                        All intellectual property rights are reserved. You may view and/or print pages from this website for your own personal use
                        subject to restrictions set in these terms and conditions.
                    </p>
                </section>
                <section className="terms-section">
                    <h2>3. User Responsibilities</h2>
                    <p>
                        As a user of our website, you agree to use the website in a manner that is lawful and respectful of others.
                        You must not use our website in any way that causes, or may cause, damage to the website or impairment of the availability
                        or accessibility of the website.
                    </p>
                </section>
                <section className="terms-section">
                    <h2>4. Limitation of Liability</h2>
                    <p>
                        In no event shall we, nor any of our officers, directors, and employees, be liable to you for anything arising out of or in any way
                        connected with your use of this website, whether such liability is under contract, tort, or otherwise, and we shall not be liable
                        for any indirect, consequential, or special liability arising out of or in any way related to your use of this website.
                    </p>
                </section>
                <section className="terms-section">
                    <h2>5. Changes to These Terms</h2>
                    <p>
                        We reserve the right to revise these terms and conditions at any time. By using this website, you are expected to review these terms
                        on a regular basis to ensure you understand all terms and conditions governing the use of this website.
                    </p>
                </section>
                <section className="terms-section">
                    <h2>6. Contact Information</h2>
                    <p>
                        If you have any questions about these Terms and Conditions, please contact us at support@example.com.
                    </p>
                </section>
            </div>
        </div>
    );
};

export default Terms;
