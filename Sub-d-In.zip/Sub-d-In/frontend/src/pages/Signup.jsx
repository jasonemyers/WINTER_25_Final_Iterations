import React from 'react';
import axios from 'axios';
import { Link } from "react-router-dom";
import "../styles/Signup.css";
 
 const Signup = () => {
 
     /* Begin API function to send info to Django */
     const handleSubmit = async (event) => {
         event.preventDefault();
 
         const username = event.target.username.value;
         const password = event.target.password.value;
         const email = event.target.email.value;
 
         const data = {
             username: username,
             password: password,
             email: email
         };
 
         <Link
            to={{
                pathname: "/create-profile",
                signup: data
            }}
        ></Link>

        window.location.href = "/create-profile";
     };
 
     return (
         <div className="signup-page">
 
             <div className="ad-container1">
                 <img
                 src="src/assets/ad2.png"
                 alt="Ad banner"
                 style={{ width: '100%', borderRadius: '0px' }}/>
             </div>
 
             <div className="signup-container">
                 <section className="signup-header">
                     <h1>Join Us Today!</h1>
                     <p>Sign up now and be part of our amazing community.</p>
                 </section>
 
 
                 <form onSubmit = {handleSubmit}>
                     <div>
                         <label htmlFor="username">Username:</label>
                         <input type="text" id="username" name="username" />
                     </div>
                     <div>
                         <label htmlFor="email">Email:</label>
                         <input type="email" id="email" name="email" />
                     </div>
                     <div>
                         <label htmlFor="password">Password:</label>
                         <input type="password" id="password" name="password" />
                     </div>
                     <button type="submit">Signup</button>
                 </form>
 
                 <section className="signup-login">
                     <p>Have an account? <a href="/login">Log in here!</a></p>
                 </section>
             </div>
 
             <div className="ad-container2">
                 <img
                 src="src/assets/ad1.png"
                 alt="Ad banner"
                 style={{ width: '100%', borderRadius: '8px' }}/>
             </div>
 
         </div>
     );
 };

 export default Signup;