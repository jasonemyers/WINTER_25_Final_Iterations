import React from 'react';
import "../styles/Login.css";
import axios from 'axios';


const Login = () => {

      // grab the button to listen for click event by using it's unique CSS id
      //const loginSubmit = document.querySelector("#login-submit-button-event-handler");

      // add the event listener: the listener will look out a "click" event on the button, and then call the function "loginSubmitClick" below
      //loginSubmit.addEventListener("click", loginSubmitClick);
      
      function loginSubmitClick(e) {
        e.preventDefault();
        console.log("Success!");
        loginUser(e);
      }

        const loginUser = async (username, password) => {
          console.log("Attempting to grab JWT from Django...");

          try {

            // hard-coding the username and password here because rn it only works with superusers in django
              const response = await axios.post(`http://127.0.0.1:8000/login/`, { username: 'madeline', password: '123456' });
              // Using drf's Simple JWT, we generate an access and a refresh JWT, and store each below
              // when you need to refresh the token, you feed the 'refresh' jwt to the api endpoint ...'login/refresh/', which will give you a longer-lived acces JWT
              localStorage.setItem('access', response.data.access);
              localStorage.setItem('refresh', response.data.refresh);

              // success message
              console.log("Got the token!");

              // NOTE: This is for development/demo purposes - normally you would not console.log the tokens!!
              console.log("Here is the access token: ", localStorage.getItem('access'));
              console.log("Here is the refresh token: ", localStorage.getItem('refresh'));

              window.location.href = "/profile";

              return response.data;
              
          } catch (error) {
              console.log("Error! No JWT for you :(", error);
          }
        }


    return (

        // container holding all login information
        <div className="login-page">

            <div className="ad-container4">
                 <img
                 src="src/assets/ad1.png"
                 alt="Ad banner"
                 style={{ width: '100%', borderRadius: '8px' }}/>
             </div>

            <div className="login-container">
                <section className="login-header">
                    <h1>Welcome back!</h1>
                    <p>Log in to access your account!</p>
                </section>

                <form action="http://127.0.0.1:8000/login/" method="POST">
                    <div>
                        <label htmlFor="username">Username:</label>
                        <input type="text" id="username" name="username" />
                    </div>
                    <div>
                        <label htmlFor="password">Password:</label>
                        <input type="password" id="password" name="password" />
                    </div>
                    <button id="login-submit-button-event-handler" onClick={loginSubmitClick}>Login</button>
                </form>
                
                <section className="login-sign-up">
                    <p>Don't have an account? <a href="/signup">Sign up here!</a></p>
                </section>
            </div>

            <div className="ad-container3">
                 <img
                 src="src/assets/ad2.png"
                 alt="Ad banner"
                 style={{ width: '100%', borderRadius: '0px' }}/>
             </div>

        </div>
    );
};

export default Login;