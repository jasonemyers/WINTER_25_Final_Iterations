import React, { useState, useEffect } from "react";
import axios from "axios";
import JobCard from "../components/JobCard";
import "../styles/JobListings.css";

const JobListings = () => {
    // state to store the job listings
    const [jobs, setJobs] = useState(null); // was empty array []
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    // fetch the job listings from the api

    useEffect(() => {
        const fetchJobs = async () => {
            try {
                const response = await axios.get("http://localhost:8000/jobs/");
                setJobs(response.data); // store the job data in state
            } catch (err) {
                setError(err);
            } finally {
                setLoading(false);
            }
        };
        fetchJobs();
    }, []);
   


    /* Mock data to test, comment out above use effect and uncomment below to test
    useEffect(() => {
        const mockJobs = [
            {
                id: 1,
                school: "Detroit Public Schools",
                teacher: "Mr. Johnson",
                grade: "10th Grade",
                subject: "Mathematics",
                accepted: false
            },
            {
                id: 2,
                school: "Ann Arbor Public Schools",
                teacher: "Ms. Smith",
                grade: "8th Grade",
                subject: "Science",
                accepted: false
            },
            {
                id: 3,
                school: "Grand Rapids Academy",
                teacher: "Mr. Brown",
                grade: "12th Grade",
                subject: "History",
                accepted: true // this job will be hidden because of acception status
            }
        ];
    
        setJobs(mockJobs); // Set mock jobs in state
        setLoading(false); // Stop loading
    }, []);
    */
    



    const resetAccepted = async () => {
        try {
            for (const job of jobs) {
                await axios.patch(`http://localhost:8000/path/jobs/${job.id}`, { accepted: false }, {
                    headers: { "Content-Type": "application/json" },
                });
            }
            console.log("All jobs reset to unaccepted.");
        } catch (error) {
            console.error("Error resetting jobs:", error.response?.data || error.message);
        }
    };

    if (loading) {
        return <p>Loading...</p>;
    } 
    if (error) {
        return <p className="error-message">Error: {error.message}</p>;
    }

    return (
        <div className="job-listings-container">
            <button onClick={resetAccepted}>
                Reset all jobs to unaccepted!
            </button>

            <div className="job-list">
                {jobs.map(job => ( // having issues when running front end connecting backend "Uncaught TypeError: jobs.map is not a function at JobListings (JobListings.jsx:93:23)"
                    <JobCard 
                        key={job.id}
                        id={job.id}
                        school={job.school}
                        teacher={job.teacher}
                        grade={job.grade}
                        subject={job.subject}
                        accepted={job.accepted}
                    />
                ))}
            </div>
        </div>
    );
};

export default JobListings;