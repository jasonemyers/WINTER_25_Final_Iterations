import React from 'react';
import "../styles/AboutUs.css";
import headshot1 from '../assets/headshot.jpg';
import headshot2 from '../assets/headshot2.jpg';
import headshot3 from '../assets/headshot3.jpg';

const AboutUs = () => {
return (
    <div className="about-us">
        <div className="about-us-container">
            <h1 className="about-us-title">About Us!</h1>
            <h1 className="logo-about-us">
                    <img src="../src/assets/logo.png" alt="Sub'd-In Logo" className="logo-image" />
            </h1>
            <p className="about-us-paragraph">
                Sub'd-In is an innovative platform set to launch soon, designed to revolutionize the way schools connect with substitute teachers. Founded in 2025 by Madeline Bartley, a former substitute teacher, Sub'd-In was born out of a vision to simplify and enhance the substitute hiring process. Madeline, along with her dedicated team—Max Lyszczyk, Emma Russo, Retaj Freeji, and Zane Christe—has worked tirelessly to create a solution that addresses the challenges faced by educators and administrators alike.
            </p>
            <p className="about-us-paragraph">
                As we prepare for our official launch, our mission remains clear. We want to provide schools with a seamless, efficient, and reliable way to find qualified substitutes. By leveraging cutting-edge technology and listening to the needs of our users, we are committed to delivering a platform that makes a real difference in the education community. Sub'd-In is more than just a tool, it is a movement to ensure every classroom has access to passionate and skilled educators when they need them most. Stay tuned as we embark on this exciting journey to transform education together.
            </p>
            <h2 className="team-title">Our Top Subs!</h2>
            <div className="teacher-images-container2">
                <div className="teacher-image-card2">
                    <div className="teacher-image2">
                        <h3 className="teacher-name2">Malcolm Lever</h3>
                        <h3 className="teacher-subject2">English, Portuguese</h3>
                        <img src={headshot3} alt="Malcolm Lever" />
                    </div>
                </div>
                <div className="teacher-image-card2">
                    <div className="teacher-image2">
                        <h3 className="teacher-name2">Ayden Hall</h3>
                        <h3 className="teacher-subject2">Math, Science, Physics</h3>
                        <img src={headshot2} alt="Ayden Hall" />
                    </div>
                </div>
                <div className="teacher-image-card2">
                    <div className="teacher-image2">
                        <h3 className="teacher-name2">Jack Blueson</h3>
                        <h3 className="teacher-subject2">History, Economics</h3>
                        <img src={headshot1} alt="Jack Blueson" />
                    </div>
                </div>
            </div>
            <div className="about-our-subs">
                <p>Our top subs are some of the best in the business. They are highly qualified and have a passion for teaching. They are ready to step in and make a difference in the classroom. We are proud to have them on our platform and we know you will be too.</p>
                <p>Malcolm Lever, an exceptional English and Portuguese tutor, discovered Sub'd-In while searching for a platform that values educators as much as he values teaching. Drawn by its mission to connect skilled substitutes with schools in need, Malcolm quickly became one of our top-rated subs, earning praise for his dedication and expertise.</p>
                <p>Ayden Hall, a talented Math, Science, and Physics tutor, found Sub'd-In while looking for a platform that prioritizes the needs of both educators and schools. Her commitment to providing quality education and her ability to adapt to different classroom environments made her a perfect fit for our platform.</p>
                <p>Jack Blueson, a passionate History and Economics tutor, discovered Sub'd-In while searching for a platform that values educators as much as he values teaching. Drawn by its mission to connect skilled substitutes with schools in need, Jack quickly became one of our top-rated subs, earning praise for his dedication and expertise.</p>
            </div>

        </div>
    </div>
);
};

export default AboutUs;