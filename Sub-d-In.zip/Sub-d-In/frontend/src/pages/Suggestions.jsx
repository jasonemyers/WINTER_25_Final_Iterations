import React from "react";
import "../styles/Suggestions.css";

const Suggestions = () => {
    return (
        <div className="suggestion-background">
            <div className="suggestion-container">
                <h1 className="suggestion-title">Submit Your Suggestions</h1>
                <p className="suggestion-intro">
                    We value your ideas! Please let us know how we can improve.
                </p>

                <form className="suggestion-form">
                    <div className="form-group">
                        <label htmlFor="name">Your Name:</label>
                        <input type="text" id="name" name="name" placeholder="Enter your name" required />
                    </div>

                    <div className="form-group">
                        <label htmlFor="email">Your Email:</label>
                        <input type="email" id="email" name="email" placeholder="Enter your email" required />
                    </div>

                    <div className="form-group">
                        <label htmlFor="suggestion">Your Suggestion:</label>
                        <textarea id="suggestion" name="suggestion" placeholder="Type your suggestion here..." required></textarea>
                    </div>

                    <button type="submit" className="suggestion-submit-button">Submit</button>
                </form>
            </div>
        </div>
    );
};

export default Suggestions;
