import React from "react"
import "../styles/Profile.css";
import SideMenu from "../components/SideMenu"
import Footer from "../components/Footer"
import ProfileContent from "../components/ProfileContent"
import UpcomingJobs from "../components/UpcomingJobs"
import MyJobCard from "../components/MyJobCard";

/*stolen default image |='_'=|*/
const Profile = () => {

    const school="Sunset Elementary";
    const date="April 15";
    const grade="5th";
    const description="Full day";
    const times="7:00am - 2:50pm";

    return (
        <div>
        {/* this is a flex container*/ }
        <div className="profile-div"> 

        {/* this is the first flex item*/}
        <div className="side-menu">
            <SideMenu />
        </div>

        {/* this is the second flex item*/}
        <div className="main-profile-content">
        <div className="image-div"> 
        <div className="hero-image"><img src="src/assets/hero-christina.jpg" width="1000"></img> </div>
        <div><img className="circle-profile-image" src="src/assets/profile-christina.jpg" width="200"></img></div>
        </div>

        
        <div className="profile-name"><h1 className="profile-name-h1">Christina Teachy</h1></div>

        {/*this will also be a flex box for the info and the upcoming jobs*/}
        <div className="profile-content">
            {/*first inner flex*/}
            <div className="profile-main">
                <p><ProfileContent /></p>
            </div>
            {/*second inner flex*/}
            <div className="upcoming-jobs"><h3 className="profile-name-h1">Upcoming jobs</h3>
                {/*Hard-coding the first job*/}
                <p className="no-upcoming-jobs">You have no upcoming jobs</p>

            </div>

        </div>
        </div>

        {/* this is the third flex item; it is only for space*/}
        <div className="spacer"></div>

        </div>
        </div>
    );
};

export default Profile