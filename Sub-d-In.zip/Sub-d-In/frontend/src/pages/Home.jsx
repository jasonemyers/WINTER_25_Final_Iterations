import React from "react";
import { Link } from "react-router-dom";
import Navbar from "../components/Navbar";
import UserAgreementPopup from "../components/UserAgreementPopup";
import "../styles/Home.css";
import MockJobCard from "../components/MockJobCard";

const Home = () => {
        
    return (
        <div className="homepage-container">
            <Navbar />
            <UserAgreementPopup />

            <div className="floating-wrapper">
            {/* Floating decor to style page */}
            <div className="floating-deco-container1">
                <img
                    src="src/assets/floatingbook.png"
                    alt="floating book"
                />
            </div>

            <div className="floating-deco-container2">
                <img
                    src="src/assets/floatingpencil.png"
                    alt="floating pencil"
                />
            </div>

            <div className="floating-deco-container3">
                <img
                    src="src/assets/floatinglaptop.png"
                    alt="floating laptop"
                />
            </div>

            <div className="floating-star1">
                <img
                    src="src/assets/star1.png"
                    alt="star1"
                />
            </div>

            <div className="floating-star2">
                <img
                    src="src/assets/star2.png"
                    alt="star2"
                />
            </div>

            <div className="floating-star3">
                <img
                    src="src/assets/star3.png"
                    alt="star3"
                />
            </div>

            <div className="floating-star4">
                <img
                    src="src/assets/star4.png"
                    alt="star4"
                />
            </div>

            <div className="floating-star5">
                <img
                    src="src/assets/star5.png"
                    alt="star5"
                />
            </div>
            </div>



            {/* Hero Section */}
            <section className="home-hero-section">
                <div className="home-hero-content">
                    <div className="home-hero-image">
                        <img
                            src="src/assets/hometext.png"
                            alt="home text"
                        />
                    </div>
                    <p>Find jobs, apply easily, and build your teaching career.</p>
                    <Link to="/signup">
                        <button className="home-primary-button">Sign Up for Free</button>
                    </Link>
                    
                    {/* I felt like we really only needed one button tbh */}
                    {/* <Link to="/login"> */}
                        {/* <button className="home-primary-button2">Log back in!</button> */}
                    {/* </Link> */}
                </div>
            </section>
            
            <section className="teacher-image-about-section">

                {/* Container holding the little bit of text and button linking to about us */}
                <div className="teacher-about-content">
                    <p>Want to learn more about us and our top rated substitutes?</p>
                    <Link to="/aboutus">
                        <button className="home-secondary-button">Click here!</button>
                    </Link>
                </div>

                {/* The container that holds all the headshots */}
                <div className="teacher-images-container">
                    {/* Image card 1 */}
                    <div className="teacher-image-card">
                        <div className="teacher-image">
                            <h3 className="teacher-name">Malcolm Lever</h3>
                            <h3 className="teacher-subject">English, Portugese</h3>
                            <img src="src/assets/headshot3.jpg" alt="Language" />
                        </div>
                    </div>
                    <div className="teacher-image-card">
                        <div className="teacher-image">
                            <h3 className="teacher-name">Ayden Hall</h3>
                            <h3 className="teacher-subject">Math, Science, Physics</h3>
                            <img src="src/assets/headshot2.jpg" alt="Genius" />
                        </div>
                    </div>
                    <div className="teacher-image-card">
                        <div className="teacher-image">
                            <h3 className="teacher-name">Jack Blueson</h3>
                            <h3 className="teacher-subject">History, Economics</h3>
                            <img src="src/assets/headshot.jpg" alt="History Teacher" />
                        </div>
                    </div>
                </div>
            </section>

            {/* How It Works Section */}
            <section className="home-how-it-works-section">
                <h2>How It Works</h2>
                <div className="home-steps-container">
                    {/* Steps containers which each have a step card */}
                    <div className="home-step-card">
                        <div className="home-step-number">1</div>
                        <h3>Create an Account</h3>
                        <p>Sign up for free and set up your professional teaching profile with your credentials and preferences.</p>
                    </div>
                    <div className="home-step-card">
                        <div className="home-step-number">2</div>
                        <h3>Browse Job Listings</h3>
                        <p>Find substitute teaching opportunities that match your schedule and location preferences.</p>
                    </div>
                    <div className="home-step-card">
                        <div className="home-step-number">3</div>
                        <h3>Apply with One Click</h3>
                        <p>Submit your application instantly and get notified when schools respond to your application.</p>
                    </div>
                </div>
            </section>
            

            <section className="home-map-section">
                <h3 className="find-jobs">Find Jobs Near You!</h3>
                <img src="src/assets/schoolMap.png" alt="Map" />

                {/* CSS for this class is in MockJobCard */}
                <div className="mock-job-card-row">
                    <MockJobCard
                        school="DPS"
                        teacher="Mrs. Jane Smith"
                        grade="6"
                        subject="English"
                        date="May 1"
                    />
                    <MockJobCard
                        school="Metro Charter Academy"
                        teacher="Mr. Adam Krumpkin"
                        grade="3-5"
                        subject="Mathematics"
                        date="May 2"
                    />
                    <MockJobCard
                        school="Edmonson Elementary"
                        teacher="Mr. Robert Jones"
                        grade="K-8"
                        subject="Physical Education"
                        date="May 3"
                        
                    />
                </div>
                <Link to="/Jobs">
                        <button className="home-jobs-button">View Jobs?</button>
                </Link>
            </section>


            {/* Testimonials Section */}
            <section className="home-testimonials-section">
                <h2>What Our Users Say!</h2>
                <div className="home-testimonials-container">
                    {/* Left Ad */}
                    <div className="home-testimonial-ad">
                        <img
                        src="src/assets/ad1.png"
                        alt="Ad banner"
                        style={{ width: '100%', borderRadius: '0px' }}/>
                    </div>

                    {/* Testimonials */}
                    <div className="home-testimonials-content">
                        <div className="home-testimonial-card">
                            <p>"Sub'd-In made it so easy to find teaching jobs! The platform is intuitive and I was able to secure multiple positions within my first week."</p>
                            <div className="home-testimonial-author">- Sarah Massachusets, Substitute Teacher</div>
                        </div>
                        <div className="home-testimonial-card">
                            <p>"I love how Sub'd-In connects me with schools that match my schedule. It's a game-changer for substitute teachers like me!"</p>
                            <div className="home-testimonial-author">- Carol Harding, Former Substitute Teacher</div>
                        </div>
                        <div className="home-testimonial-card">
                            <p>"Thanks to Sub'd-In, I found a long-term substitute position at a school I love. The process was seamless and stress-free."</p>
                            <div className="home-testimonial-author">- James Dennis, Substitute Teacher</div>
                        </div>
                    </div>

                    {/* Mock ad on right */}
                    <div className="home-testimonial-ad">
                        <img
                        src="src/assets/ad2.png"
                        alt="Ad banner"
                        style={{ width: '100%', borderRadius: '0px' }}/>
                    </div>
                </div>
            </section>



            {/* Footer Navigation */}
            {/* Possibly implement footer like header where it is available everywhere? */}
            <footer className="home-footer-section">
                <div className="home-footer-content">
                    <div className="home-footer-column">
                        <h3>Company</h3>
                        <Link to="/aboutus">About Us</Link>
                        <Link to="#">Contact</Link>
                        {/* REMOVE LATER */}
                        <Link to="/create-profile">Profile Creator</Link>

                    </div>
                    <div className="home-footer-column">
                        <h3>Support</h3>
                        <Link to="#">Help Center</Link>
                        <Link to="/Terms">Terms of Service</Link>
                        <Link to="/PrivacyPolicy">Privacy Policy</Link>
                        
                    </div>
                    <div className="home-footer-column">
                        <h3>Connect</h3>
                        <a href="#" className="social-link">Twitter</a>
                        <a href="#" className="social-link">LinkedIn</a>
                        <Link to="/Suggestions">Suggest a feature</Link>
                        {/* Below is what we could say for our question page */}
                        {/* <p>We are constantly working to improve our platform and add new features. We are committed to providing the best possible experience for our users. If you have any questions or suggestions, please feel free to reach out to us.</p> */}
                        
                    </div>
                </div>

            </footer>
        </div>
    );
};

export default Home;