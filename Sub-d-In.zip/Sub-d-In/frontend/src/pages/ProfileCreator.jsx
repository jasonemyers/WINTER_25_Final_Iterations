// this page will hold everything needed for profile form.jsx

import React from 'react';
import ProfileForm from '../components/ProfileForm';
import '../styles/ProfileCreator.css';
import Footer from '../components/Footer';

const ProfileCreator = () => {
    return (
        <div className="profile-creator-page">
            <section className="profile-creator-header">
                <h1>Create Your Profile!</h1>
            </section>
            <ProfileForm/>
            <Footer/>
        </div>
    );
};

export default ProfileCreator;