import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar"; // Import the Navbar component

// import pages we will route to
import Home from "./pages/Home";
import Joblistings from "./pages/JobListings";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import AboutUs from "./pages/AboutUs";
import Profile from "./pages/Profile";
import ProfileCreator from "./pages/ProfileCreator";
import Terms from "./pages/Terms";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import Suggestions from "./pages/Suggestions";

function App() {
  return (
    <div>
    <Router>
      <Navbar/>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/jobs" element={<Joblistings />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/aboutus" element={<AboutUs />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/terms" element={<Terms />} />
        <Route path="/privacypolicy" element={<PrivacyPolicy />} />
        <Route path="/create-profile" element={<ProfileCreator />} />
        <Route path="/suggestions" element={<Suggestions />} />
      </Routes>
    </Router>

    </div>
  );
}

export default App;