
from django.shortcuts import render
from rest_framework.response import Response



def home(request):
    return render(request, 'home.html')