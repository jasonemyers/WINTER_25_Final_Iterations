from django.db import models
from django.contrib.auth.models import User

class User(User):
    # note: django model will not enforce the max word count, you'll have to validate the word count on the frontend in React
    # remove blank = true after deleting test users, and adding defaults
    bio = models.TextField(blank=True)
    subjects = models.TextField(blank=True)
    location = models.TextField(blank=True)
    avatar = models.ImageField(blank=True, upload_to='../../media/avatars')

    def __str__(self):
        return self.id
    
    # note: username, email, password, first_name, last_name are already in the user model, no need to redefine the field above
    # the fields above are for EXTENDING the User model class (ie adding the fields that do not come with the class)
    class Meta:
        ordering = ['id', 'username', 'email', 'password', 'first_name', 'last_name', 'is_active', 'bio', 'subjects', 'location', 'avatar',]