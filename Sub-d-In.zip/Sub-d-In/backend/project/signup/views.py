from rest_framework import viewsets
from django.contrib.auth.models import User
from signup.serializers import UserSerializer

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework_simplejwt.authentication import JWTAuthentication

from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)


from . import serializers

class CustomTokenObtainPairView(TokenObtainPairView):
    # Replace the serializer with your custom
    serializer_class = serializers.CustomTokenObtainPairSerializer


class UserViewSet(viewsets.ModelViewSet):
    """
    This viewset automatically provides `list` and `retrieve` actions.
    """
    queryset = User.objects.all()
    serializer_class = UserSerializer
    

# basic view for getting Simple JWT
class Login(APIView):
    authentication_classes = [JWTAuthentication]
    def get(self, request):
        content = {'message': 'Hello, World!'}
        return Response(content)


