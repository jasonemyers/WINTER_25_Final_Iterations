from django.urls import path
from .views import UserViewSet
#from rest_framework.urlpatterns import format_suffix_patterns
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)

admin_user_profiles = UserViewSet.as_view({
    'get': 'retrieve',
    'get': 'list',
    'put': 'update',
    'patch': 'partial_update',
    'delete': 'destroy'
})

profiles = UserViewSet.as_view({
    'get': 'list',
    'post': 'create'
})

admin_delete_user = UserViewSet.as_view({
    'get': 'retrieve',
    'delete' : 'destroy',
    'put': 'update',
    'patch': 'partial_update',
})


urlpatterns = [
    # API endpoint for creating a new profile (use this one on frontend)
    path('signup/', profiles),
    # ADMIN ONLY page for deleting users from the system (NOT and API endpoint, do not use on frontend)
    path('admin-update-user/<int:pk>', admin_delete_user),
    # ADMIN ONLY page for viewing and editing user profiles, NOT the pages that the users will see on the frontend, do not use on the frontend)
    path('admin-user-profiles/', admin_user_profiles),
    path('login/', TokenObtainPairView.as_view(), name='login'),
    path('login/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
]