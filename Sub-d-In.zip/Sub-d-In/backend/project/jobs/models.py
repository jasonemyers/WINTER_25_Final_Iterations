from django.db import models

# Create your models here.

class Jobs(models.Model):
    school = models.TextField(blank=True)
    grade = models.PositiveSmallIntegerField(blank=True)
    teacher = models.TextField(blank=True)
    subject = models.TextField(blank=True)
    accepted = models.BooleanField(default=False)

    def __str__(self):
        return self.id
    
    class Meta:
        ordering = ['school', 'grade', 'teacher', 'subject', 'accepted',]

