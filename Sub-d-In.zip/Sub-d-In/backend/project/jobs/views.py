from .serializer import JobSerializer

# Create your views here.

from rest_framework import viewsets
from jobs.models import Jobs



class JobsViewSet(viewsets.ModelViewSet):
    queryset = Jobs.objects.all()
    serializer_class = JobSerializer


