# Installation/Viewing Instructions
Our app is hosted to GitHub pages. To view our current iteration, simply go to the following link: https://wsu-software-engineering-group-12.github.io/Cabinet-Generator/.

GitHub pages hosts the frontend, and we are currently working on getting the backend hosted. It works on local machines, but needs a hosting service. This is our main focus currently, and will be changed soon. However, at the moment, no major functionality is missed from disconnecting the frontend from the backend.
