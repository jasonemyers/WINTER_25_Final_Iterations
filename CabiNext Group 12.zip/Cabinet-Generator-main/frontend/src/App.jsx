import RoomManager from './components/RoomManager/RoomManager.jsx';
import './App.css';


function App() {
  return (
    <div className='container'>
      <RoomManager className='column' />
    </div>
  )
}

export default App;
