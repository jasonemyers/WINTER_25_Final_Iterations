const Footer = () => {
  return (
    <footer className="bg-white border-t h-16 flex items-center justify-center">
      Footer Placeholder
    </footer>
  )
}

export default Footer
