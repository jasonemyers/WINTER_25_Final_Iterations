export interface JobDescription {
    description: string
    tasks: string[]
  }
  